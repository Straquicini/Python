from db import get_db
from flask import Flask, render_template, request, redirect

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/pacientes")
def pacientes():
    conn = get_db()
    cursor = conn.cursor(dictionary=True)
    sql = "SELECT * from paciente"
    cursor.execute(sql)
    lista_de_pacientes = cursor.fetchall()
    return render_template("paciente.html", pacientes=lista_de_pacientes)

@app.route("/medicos")
def medicos():
    conn = get_db()
    cursor = conn.cursor(dictionary=True)
    sql = "SELECT * from medicos"
    cursor.execute(sql)
    lista_de_medicos = cursor.fetchall()
    return render_template("medicos.html", medicos=lista_de_medicos)


@app.route("/pacientes/novo", methods=["POST"])
def inserir_paciente():
    nome = request.form["txt_nome"]
    tlm = request.form["txt_tlm"]
    dtnasc = request.form["txt_dtnasc"]
    
    conn = get_db()
    cursor = conn.cursor()
    
    sql = "INSERT INTO paciente (nome, contato, data_nascimento) VALUES (%s,%s,%s)"
    cursor.execute(sql, (nome, tlm, dtnasc))
    conn.commit()
    conn.close()
    return redirect("/pacientes")

@app.route("/medicos/novo", methods=["POST"])
def inserir_medico():
    nomeM = request.form["txt_nomeM"]
    tlmM = request.form["txt_tlmM"]
    espc = request.form["txt_espc"]
    
    conn = get_db()
    cursor = conn.cursor()
    
    sql = "INSERT INTO medicos (nome, contato, idespecialidade) VALUES (%s,%s,%s)"
    cursor.execute(sql, (nomeM, tlmM, espc))
    conn.commit()
    conn.close()
    
    return redirect("/medicos")

@app.route("/consulta")
def consultas():
    conn = get_db()
    cursor = conn.cursor(dictionary=True)

    sql = "SELECT id_consulta, idmedico, idpaciente, data_consulta, observacoes FROM consultas"
    cursor.execute(sql)
    lista_de_consultas = cursor.fetchall()

    conn.close()
    return render_template("consulta.html", consultas=lista_de_consultas)

@app.route("/nova_consulta", methods=["POST"])
def inserir_consulta():
    idM = request.form["txt_idM"]
    idP = request.form["txt_idP"]
    dtcslt = request.form["txt_dtcslt"]
    obs = request.form["txt_obs"]
    
    conn = get_db()
    cursor = conn.cursor()
    
    sql = "INSERT INTO consultas (idmedico, idpaciente, data_consulta, observacoes) VALUES (%s,%s,%s,%s)"
    cursor.execute(sql, (idM, idP, dtcslt, obs))
    conn.commit()
    conn.close()
    
    return redirect("/consulta")

app.run(debug=True)