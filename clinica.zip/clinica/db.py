from mysql.connector import MySQLConnection

def get_db():
    return MySQLConnection(
        host="localhost",
        port="3307",
        user="root",
        password="root",
        database="clinica"
    )